console.log('compilou js')

const calcular = document.querySelector('#calculate');

calcular.addEventListener('click', function (e) {
    e.preventDefault();
    const capacidadeBateria = document.querySelector('#battery-capacity-id').value;
    const medidaCapacidadeBateria = document.querySelector('#unit-battery-capacity').value;
    const potenciaCarregador = document.querySelector('#charger-amper-id').value;
    const medidaPotenciaCarregador = document.querySelector('#unit-charger-amper').value;

    //medidas para calculo
    let capacidademAh = capacidadeBateria;
    let carregamentomA = potenciaCarregador;

    //Converter valores
    /* conversão da capacidade de armazenamento */
    if (medidaCapacidadeBateria === 'Ah') {
        capacidademAh = capacidadeBateria * 1000;
        //console.log(medidaCapacidadeBateria)
        //console.log(capacidademAh)
    };
    /* conversão da capacidade de carregamento */
    if (medidaPotenciaCarregador === 'A') {
        carregamentomA = potenciaCarregador * 1000;
        //console.log(medidaPotenciaCarregador)
        //console.log(carregamentomA)
    } else if (medidaPotenciaCarregador === 'kA') {
        carregamentomA = potenciaCarregador * 1000;
        //console.log(medidaPotenciaCarregador)
        //console.log(carregamentomA)
    };

    //calcula resultado
    let tempoCarregamento = 0;
    tempoCarregamento = (capacidademAh / carregamentomA) * 60
    //console.log(tempoCarregamento)
    let horasCarregamento = Math.floor(tempoCarregamento / 60);// pega o valor inteiro arredondado para obter as horas 
    let minutosCarregamento = tempoCarregamento % 60;
    //console.log('Horas: '+horasCarregamento+" | Minutos: "+minutosCarregamento);


    document.querySelector('#result-output').innerHTML = ('Resultado: ' + horasCarregamento + ' horas e ' + minutosCarregamento + ' minutos')

    if (document.querySelector('#result-output').innerHTML == ('Resultado: NaN horas e NaN minutos')){
        document.querySelector('#result-output').innerHTML = ('Resultado: ' + 0 + ' horas e ' + 0 + ' minutos')
    } else if (document.querySelector('#result-output').innerHTML == ('Resultado: Infinity horas e NaN minutos')){
        document.querySelector('#result-output').innerHTML = ('Resultado: ' + 0 + ' horas e ' + 0 + ' minutos')
    }

});